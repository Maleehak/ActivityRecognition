import FeatureExtraction as fe
import cv2
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication,QWidget,QInputDialog,QLineEdit,QFileDialog
#Background Substraction
import os
import cv2
import numpy as np
import re
import math
import pandas as pd

#Background Subsraction
def natural_sort_key(s, _nsre=re.compile('([0-9]+)')):
    '''
    Returns the text in the natural numberical assending order
    '''
    return [
        int(text)
        if text.isdigit() else text.lower()
        for text in _nsre.split(s)]

def dilation(frame):
    '''
    Takes the frame  and perform dilation
    Inputs:
        frame: numpy array
    Parameters:
        dilated numpy array
    '''
    frame = cv2.dilate(frame, None, iterations=3)
    return frame

def gaussian_blur(frame):
    '''
    Takes the frames  and perform gaussian blur
    Parameters:
        frame: numpy array
    Returns:
        blured numpy array
    '''
    frame=cv2.GaussianBlur(frame, (21, 21), 0)
    return frame


def background_subtraction(frame1,frame2):
    '''
    Takes two frames  and perform background subtraction on frame2 based on frame1
    Parameters:
        frame1: numpy array
        frame2: numpy array
    Returns:
        binarized frame
    '''
    difference = cv2.absdiff(frame1, frame2)
    thresh = cv2.threshold(difference, 255/2, 255, cv2.THRESH_BINARY)[1]
    return thresh


def subtract_background(read_folder,write_folder):
    '''
    Reads the frames in gray scale from the folder, applies blur and saves new 
    frame in the folder
    
    Parameters:
        read_folder: folder to read frames from
        write_folder: folder to save frames after applying blur
    '''
    write_folder=r"C:\Users\kiran\Documents\Activity Analysi\Background Subsraction"
    files = [file for file in os.listdir(read_folder)]
    sorted_files = sorted(files, key=natural_sort_key)
    
    frames = []
    for file in sorted_files:
        frame = cv2.imread(read_folder+"/"+file,0)
        frame = gaussian_blur(frame)
        frames.append(frame)
        
        
    first_frame = frames[0]
    frames_except_first = np.array(frames[1:])
    i = 0
    for frame in frames_except_first:
        frame = background_subtraction(frame,first_frame)
        frame = dilation(frame)
        cv2.imwrite(write_folder+"/"+str(i)+'.jpg',frame)
        i = i+1

#Skeleton
def skeletonize(frame):
    '''
    Applies cross morphological structuring on image   
    Parameters:
        frame: numpy array
    Returns:
        skel: numpy array after skeletonization
    '''
    size = np.size(frame)
    element = cv2.getStructuringElement(cv2.MORPH_CROSS,(3,3))
    done = False

    skel=np.zeros(frame.shape,np.uint8)
    while( not done):
        eroded = cv2.erode(frame,element)
        temp = cv2.dilate(eroded,element)
        temp = cv2.subtract(frame,temp)
        skel = cv2.bitwise_or(skel,temp)
        frame = eroded.copy()
        zeros = size - cv2.countNonZero(frame)
        if zeros==size:
            done = True
    return skel

    
def natural_sort_key(s, _nsre=re.compile('([0-9]+)')):
    '''
    Returns the text in the natural numberical assending order
    '''
    return [
        int(text)
        if text.isdigit() else text.lower()
        for text in _nsre.split(s)]



def frames_skeletonization(read_folder,write_folder):
    '''
    Applies skeletonization on each frame in read folder and saves skeletonized 
    frame in the folder
    
    Parameters:
        read_folder: folder to read frames from
        write_folder: folder to save frames after skeletonization
    '''
    write_folder=r"C:\Users\kiran\Documents\Activity Analysi\Skeletonization"
    files = [file for file in os.listdir(read_folder)]
    sorted_files = sorted(files, key=natural_sort_key)
    
    i = 0
    for file in sorted_files:
        frame = cv2.imread(read_folder+"/"+file,0)
        skel = skeletonize(frame)
        cv2.imwrite(write_folder+"/"+str(i)+'.jpg',skel)
        i = i+1

#Hough Transformation

def natural_sort_key(s, _nsre=re.compile('([0-9]+)')):
    '''
    Returns the text in the natural numberical assending order
    '''
    return [
        int(text)
        if text.isdigit() else text.lower()
        for text in _nsre.split(s)]


def hough_transform(skeleton):
    '''
    Applies hough transform on skeletonized image   
    Parameters:
        frame:  skeletonized numpy array
    Returns:
        new_img: new image with hough transformations
    '''
    element = cv2.getStructuringElement(cv2.MORPH_CROSS,(3,3))
    new_img = np.zeros((skeleton.shape[0],skeleton.shape[1]))
    v = np.median(skeleton)
    sigma = 0.1

    lower = int(max(0, (1.0 - sigma) * v))
    upper = int(min(255, (1.0 + sigma) * v)) 

    #canny edge
    edges = cv2.Canny(skeleton, lower, upper)
    dilated_edges = cv2.dilate(edges,element)
    lines = cv2.HoughLinesP(dilated_edges, rho=2, theta=np.pi/180,
                            threshold=120, minLineLength=10, maxLineGap=56)
    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            cv2.line(new_img, (x1, y1), (x2, y2), (255, 0, 0), 1)
    return new_img


def hough_transformation(read_folder,write_folder):
    '''
    Applies hough transform on each frame in read folder and saves skeletonized 
    frame in the folder
    
    Parameters:
        read_folder: folder to read frames from
        write_folder: folder to save frames after hough transform
    '''
    write_folder=r"C:\Users\kiran\Documents\Activity Analysi\HoughTransform"
    files = [file for file in os.listdir(read_folder)]
    sorted_files = sorted(files, key=natural_sort_key)
    i = 0
    for file in sorted_files:
        print(read_folder+"/"+file)
        frame = cv2.imread(read_folder+"/"+file,0)
        skel = hough_transform(frame)
        cv2.imwrite(write_folder+"/"+str(i)+'.jpg',skel)
        i = i+1
 
#CSV Features

def create_csv(feature_vector,feature_header, file_name, class_name):
    '''
   create feature file from the given feature vector
    
    Parameters:
        feature_vector: numpy array
        feature_header: list of feature names
        file_name: path and filename to store vector in
        class_name: class of the features extracted
    Returns:
       None
    '''
    feature_vector = np.array(feature_vector)
    np.savetxt(file_name, feature_vector, delimiter=",")
    df = pd.read_csv(file_name, header=None)
    df.columns = feature_header
    df['class'] = class_name
    df.to_csv(file_name)
    
#Capture Frames
def capture_frames(video , folder):
    '''
    Captures all the frames from the video and stores them in a folder
    Parameters:
        video : path of video
        folder : path of folder
    Returns:
        None
    '''
    i = 0
    cap = cv2.VideoCapture(video)
    scaling_factorx=5
    scaling_factory=5
    
    while(cap.isOpened()):
        ret, frame = cap.read()
        if not ret:
            break
        frame=cv2.resize(frame,None,fx=scaling_factorx,fy=scaling_factory,interpolation=cv2.INTER_AREA)
        cv2.imwrite(folder+"/"+str(i)+'.jpg',frame)
        i = i+1 
        
#interface

class Ui_Dialog(object):
    videoLink=" "
    frameLink=" "
    def select_file(self):
        filename=QFileDialog.getOpenFileName()
        self.videoTextEdit.setText(filename[0])
        print(filename[0])
    def select_folder(self):
        file=QFileDialog.getExistingDirectory()
        self.frameTextEdit.setText(file)
        print(file)
#     def videoToFrameConvertor(self):
#         videoLink=self.videoTextEdit.toPlainText()
#         frameLink=self.frameTextEdit.toPlainText()
#         videoCaptured = cv2.VideoCapture(videoLink)
#         success,image = videoCaptured.read()
#         count = 0
#         while success:
#             cv2.imwrite(frameLink+"\\frame%d.jpg" % count, image)     # save frame as JPEG file      
#             success,image = videoCaptured.read()
#             print('Read a new frame: ', success)
#             count += 1
    def videoToFrameConvertor(self):
        videoLink=self.videoTextEdit.toPlainText()
        frameLink=self.frameTextEdit.toPlainText()
        capture_frames(videoLink,frameLink)  
    def backgroundSubstractor(self):
        frameLink=self.frameTextEdit.toPlainText()
        frameLink=self.frameTextEdit.toPlainText()
        subtract_background(frameLink, frameLink)
    def skeletonization(self):
        frameLink=self.frameTextEdit.toPlainText()
        frameLink=self.frameTextEdit.toPlainText()
        frames_skeletonization(frameLink,frameLink)
    def houghTransformed(self):
        frameLink=self.frameTextEdit.toPlainText()
        frameLink=self.frameTextEdit.toPlainText()
        hough_transformation(frameLink,frameLink)
    def extractFeature(self):
        frameLink=self.frameTextEdit.toPlainText()
        feature_vector, feature_header = fe.feature_extraction(frameLink)
        print("Feature vector is")
        print(feature_vector)
        print("Feature Header is ")
        print(feature_header)
    def createCSV(self):
        frameLink=self.frameTextEdit.toPlainText()
        feature_vector, feature_header = fe.feature_extraction(frameLink)
        file_name = 'features.csv'
        class_name = 'walking'
        create_csv(feature_vector,feature_header, file_name, class_name)
        
        
         
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(541, 267)
        # video frames button
        self.videoToFrame = QtWidgets.QPushButton(Dialog)
        self.videoToFrame.setGeometry(QtCore.QRect(10, 10, 91, 23))
        self.videoToFrame.setObjectName("videoToFrame")
        self.videoToFrame.clicked.connect(self.videoToFrameConvertor)
        self.background = QtWidgets.QPushButton(Dialog)
        # background substraction Button
        self.background.setGeometry(QtCore.QRect(100, 10, 75, 23))
        self.background.setObjectName("background")
        self.background.clicked.connect(self.backgroundSubstractor)
        #Skeleton Button
        self.skeleton = QtWidgets.QPushButton(Dialog)
        self.skeleton.setGeometry(QtCore.QRect(170, 10, 75, 23))
        self.skeleton.setObjectName("skeleton")
        self.skeleton.clicked.connect(self.skeletonization)
        #Hough Transformation Button
        self.houghTransformation = QtWidgets.QPushButton(Dialog)
        self.houghTransformation.setGeometry(QtCore.QRect(240, 10, 75, 23))
        self.houghTransformation.setObjectName("houghTransformation")
        self.houghTransformation.clicked.connect(self.houghTransformed)
        #Feature Extraction Button
        self.featureExtraction = QtWidgets.QPushButton(Dialog)
        self.featureExtraction.setGeometry(QtCore.QRect(310, 10, 111, 23))
        self.featureExtraction.setObjectName("featureExtraction")
        self.featureExtraction.clicked.connect(self.extractFeature)
        #To CSV BUtton
        self.csv = QtWidgets.QPushButton(Dialog)
        self.csv.setGeometry(QtCore.QRect(420, 10, 75, 23))
        self.csv.setObjectName("csv")
        self.csv.clicked.connect(self.createCSV)
        #Choose video file button
        self.chooseVideoFolder = QtWidgets.QPushButton(Dialog)
        self.chooseVideoFolder.setGeometry(QtCore.QRect(130, 90, 75, 23))
        self.chooseVideoFolder.setObjectName("chooseVideoFolder")
        self.chooseVideoFolder.clicked.connect(self.select_file)
        #Choose Frame Folder Button
        self.chooseFramesFolder = QtWidgets.QPushButton(Dialog)
        self.chooseFramesFolder.setGeometry(QtCore.QRect(130, 150, 75, 23))
        self.chooseFramesFolder.setObjectName("chooseFramesFolder")
        self.chooseFramesFolder.clicked.connect(self.select_folder)
        #Text Field to show video link
        self.videoTextEdit = QtWidgets.QTextEdit(Dialog)
        self.videoTextEdit.setGeometry(QtCore.QRect(240, 90, 171, 31))
        self.videoTextEdit.setObjectName("videoTextEdit")
        #Text Field to show Frame Folder
        self.frameTextEdit = QtWidgets.QTextEdit(Dialog)
        self.frameTextEdit.setGeometry(QtCore.QRect(240, 140, 171, 31))
        self.frameTextEdit.setObjectName("frameTextEdit")
        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
      
    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.videoToFrame.setText(_translate("Dialog", "Video To frame"))
        self.background.setText(_translate("Dialog", "Background"))
        self.skeleton.setText(_translate("Dialog", "Skeleton"))
        self.houghTransformation.setText(_translate("Dialog", "Hough"))
        self.featureExtraction.setText(_translate("Dialog", "Feature Extraction"))
        self.csv.setText(_translate("Dialog", "CSV"))
        self.chooseVideoFolder.setText(_translate("Dialog", "Choose"))
        self.chooseFramesFolder.setText(_translate("Dialog", "Choose"))

#Main function

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

